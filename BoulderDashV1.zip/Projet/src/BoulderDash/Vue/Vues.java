/**
 * 
 */
package BoulderDash.Vue;

/**
 * Enumération des différentes vues
 * 
 * @author 4r3
 * 
 */
public enum Vues {
	MENUPRINCIPAL, MENUCHOIXNIVEAU, TABLEAUJEU, TABLEAUEDITEUR
}
