/**
 * 
 */
package BoulderDash.Modele.Cases;

/**
 * Liste des directions que le personnage peut prendre
 *
 */
public enum Directions {
	Haut, Bas, Gauche, Droite, Null;
}
