/**
 * 
 */
package BoulderDash.Modele.Cases;

/**
 * Liste des différents états qu'un objet chutable peut avoir
 * 
 */
public enum EtatChutable {
	Stable, Instable, Chute
}
