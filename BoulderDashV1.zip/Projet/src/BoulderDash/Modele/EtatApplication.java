/**
 * 
 */
package BoulderDash.Modele;

/**
 * liste des états possibles pour l'application
 */
public enum EtatApplication {
	MenuPrincipal, ChoixNiveau, Jeu
}
