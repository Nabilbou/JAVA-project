/**
 * 
 */
package BoulderDash.Vue;

/**
 * Enumération des différentes vues
 * 
 * 
 * 
 */
public enum Vues {
	MENUPRINCIPAL, MENUCHOIXNIVEAU, TABLEAUJEU, TABLEAUEDITEUR
}
