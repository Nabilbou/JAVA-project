/**
 * 
 */
package tassoune;



import org.junit.BeforeClass;
import org.junit.Test;

import BoulderDash.Modele.Jeu;

/**
 * @author Amir
 *
 */
public class TestJeux {

	
	@BeforeClass
	public static void setUpBeforeClass() {
	}

	
	
	Jeu j= new Jeu();
	/**
	 * Test method for {@link BoulderDash.Modele.Jeu#getNiveau()}.
	 */
	@Test
	public void testGetNiveau() {
		
		
		
		j.getNiveau();
		
	}

}
