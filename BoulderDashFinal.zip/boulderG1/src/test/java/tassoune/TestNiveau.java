/**
 * 
 */
package tassoune;



import org.junit.BeforeClass;
import org.junit.Test;

import BoulderDash.Modele.Niveau;



/**
 * @author Amir
 *
 */
public class TestNiveau {


	 	
	 
	@BeforeClass
	public static   void setUpBeforeClass()  {
	}
	
	Niveau nj = new Niveau();
	
	@Test
	public void testaddRemplirUptable() {
		
		nj.addUptable(5, 4);
		nj.addUptable(7, 4);
		
	}
	
	
public void test2addRemplirUptable() {
		Niveau nj =new Niveau(5,8);
		nj.addUptable(4, 5);
		nj.addUptable(2, 4);
}
	
public void testGetPerso(){
		
		nj.getPerso();
		
	}

}
