/**
 * 
 */
package BoulderDash.Modele;

/**
 * lists the possible states for the application
 */
public enum EtatApplication {
	MenuPrincipal, ChoixNiveau, Jeu
}
