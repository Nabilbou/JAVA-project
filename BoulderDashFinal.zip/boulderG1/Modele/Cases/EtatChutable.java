/**
 * 
 */
package BoulderDash.Modele.Cases;

/**
 * 
 * liste of different states that a falling object could have
 */
public enum EtatChutable {
	Stable, Instable, Chute
}
