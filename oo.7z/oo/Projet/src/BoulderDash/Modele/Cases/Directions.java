/**
 * 
 */
package BoulderDash.Modele.Cases;

/**
 * 
 * list of the directions that the character could take
 */
public enum Directions {
	Haut, Bas, Gauche, Droite, Null;
}
